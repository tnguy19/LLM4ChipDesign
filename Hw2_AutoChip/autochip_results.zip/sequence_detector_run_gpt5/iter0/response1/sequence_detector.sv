module sequence_detector_3b (
    input  wire       clk,       // Clock
    input  wire       rst_n,     // Active-low reset
    input  wire [2:0] data,      // 3-bit data input
    output reg        seq_found  // 1-cycle pulse when sequence is found
);
    // Pattern tokens (3-bit symbols)
    localparam [2:0] P0 = 3'b001;
    localparam [2:0] P1 = 3'b101;
    localparam [2:0] P2 = 3'b110;
    localparam [2:0] P3 = 3'b000;
    localparam [2:0] P4 = 3'b110;
    localparam [2:0] P5 = 3'b110;
    localparam [2:0] P6 = 3'b011;
    localparam [2:0] P7 = 3'b101;

    // State encodes how many consecutive symbols from the start of the pattern have matched so far.
    // Valid range: 0..7 (next match would complete the sequence)
    reg [3:0] state, next_state;

    // Next-state logic (KMP-like with trivial fallback since this pattern has no proper borders)
    always @* begin
        case (state)
            4'd0: next_state = (data == P0) ? 4'd1 : 4'd0;

            4'd1: next_state = (data == P1) ? 4'd2 :
                               (data == P0) ? 4'd1 : 4'd0;

            4'd2: next_state = (data == P2) ? 4'd3 :
                               (data == P0) ? 4'd1 : 4'd0;

            4'd3: next_state = (data == P3) ? 4'd4 :
                               (data == P0) ? 4'd1 : 4'd0;

            4'd4: next_state = (data == P4) ? 4'd5 :
                               (data == P0) ? 4'd1 : 4'd0;

            4'd5: next_state = (data == P5) ? 4'd6 :
                               (data == P0) ? 4'd1 : 4'd0;

            4'd6: next_state = (data == P6) ? 4'd7 :
                               (data == P0) ? 4'd1 : 4'd0;

            4'd7: next_state = (data == P7) ? 4'd0 :  // full match completes; no proper border -> go to 0
                               (data == P0) ? 4'd1 : 4'd0;

            default: next_state = 4'd0;
        endcase
    end

    // State register and match pulse generation
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= 4'd0;
            seq_found <= 1'b0;
        end else begin
            // Assert seq_found for one clock when the final symbol matches
            seq_found <= (state == 4'd7) && (data == P7);
            state     <= next_state;
        end
    end

endmodule
