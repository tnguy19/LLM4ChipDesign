module sequence_detector(
    input wire Clock,
    input wire reset_n,  // Active-low reset
    input wire [2:0] Data,
    output reg SequenceFound
);

    // State definitions
    localparam S0 = 4'd0;  // Initial state
    localparam S1 = 4'd1;  // Detecting 0b001
    localparam S2 = 4'd2;  // Detecting 0b101
    localparam S3 = 4'd3;  // Detecting 0b110
    localparam S4 = 4'd4;  // Detecting 0b000
    localparam S5 = 4'd5;  // Detecting 0b110 again
    localparam S6 = 4'd6;  // Detecting another 0b110
    localparam S7 = 4'd7;  // Detecting 0b011
    localparam S8 = 4'd8;  // Detecting 0b101

    reg [3:0] current_state, next_state;

    // State transition logic
    always @(posedge Clock or negedge reset_n) begin
        if (!reset_n)
            current_state <= S0;
        else
            current_state <= next_state;
    end

    // Next state logic
    always @(*) begin
        case (current_state)
            S0: next_state = (Data == 3'b001) ? S1 : S0;
            S1: next_state = (Data == 3'b101) ? S2 : S0;
            S2: next_state = (Data == 3'b110) ? S3 : S0;
            S3: next_state = (Data == 3'b000) ? S4 : S0;
            S4: next_state = (Data == 3'b110) ? S5 : S0;
            S5: next_state = (Data == 3'b110) ? S6 : S0;
            S6: next_state = (Data == 3'b011) ? S7 : S0;
            S7: next_state = (Data == 3'b101) ? S8 : S0;
            S8: next_state = S0;
            default: next_state = S0;
        endcase
    end

    // Output logic
    always @(*) begin
        SequenceFound = (current_state == S8);
    end

endmodule
