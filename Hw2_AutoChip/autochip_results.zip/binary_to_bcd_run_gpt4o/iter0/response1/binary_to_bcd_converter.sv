module binary_to_bcd_converter (
    input [4:0] binary_in,
    output reg [7:0] bcd_out
);
    integer i;
    reg [7:0] bcd;

    always @(binary_in) begin
        // Initialize BCD to zero
        bcd = 8'b0;

        // Convert binary_in to BCD using double-dabble algorithm
        for (i = 0; i < 5; i = i + 1) begin
            // Shift left by 1
            bcd = {bcd[6:0], binary_in[4 - i]};

            // If the lower 4 bits are greater than or equal to 5, add 3
            if (bcd[3:0] >= 4'd5)
                bcd[3:0] = bcd[3:0] + 4'd3;

            // If the higher 4 bits are greater than or equal to 5, add 3
            if (bcd[7:4] >= 4'd5)
                bcd[7:4] = bcd[7:4] + 4'd3;
        end

        bcd_out = bcd;
    end
endmodule
