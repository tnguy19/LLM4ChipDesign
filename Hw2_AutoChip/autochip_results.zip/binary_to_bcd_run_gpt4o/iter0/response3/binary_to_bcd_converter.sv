module binary_to_bcd_converter(
    input [4:0] binary_in,
    output reg [7:0] bcd_out
);
    integer i;
    
    always @(binary_in) begin
        // Initialize BCD output
        bcd_out = 8'b0;

        // Temporary register to hold BCD value during conversion
        reg [7:0] temp_bcd;
        temp_bcd = 8'b0;

        // Convert binary to BCD using shift-and-add-3 algorithm
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift temporary BCD number left by 1
            temp_bcd = {temp_bcd[6:0], binary_in[i]};
            
            // If 4 bits in the units or tens place are 5 or more, add 3
            if (temp_bcd[3:0] > 4)
                temp_bcd[3:0] = temp_bcd[3:0] + 3;
            if (temp_bcd[7:4] > 4)
                temp_bcd[7:4] = temp_bcd[7:4] + 3;
        end
        
        // Assign result to output
        bcd_out = temp_bcd;
    end
endmodule
