module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,   // Active-low reset
    input  wire [2:0]  data,
    output wire        sequence_found
);

    // Shift register holds the last 8 symbols (8 * 3 bits = 24 bits)
    reg [23:0] shift_reg;

    // Target pattern: 0b001, 0b101, 0b110, 0b000, 0b110, 0b110, 0b011, 0b101
    localparam [23:0] PATTERN = 24'b001_101_110_000_110_110_011_101;

    // Asynchronous active-low reset; shift in current data each clock
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            shift_reg <= 24'd0;
        end else begin
            shift_reg <= {shift_reg[20:0], data};
        end
    end

    // Combinational detection using the next shift window (Mealy-style, zero latency)
    assign sequence_found = reset_n && ({shift_reg[20:0], data} == PATTERN);

endmodule
