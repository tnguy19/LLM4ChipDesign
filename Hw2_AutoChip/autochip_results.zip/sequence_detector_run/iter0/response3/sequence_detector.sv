module sequence_detector (
    input wire clk,
    input wire n_rst,
    input wire [2:0] data,
    output reg seq_found
);
    reg [3:0] state;
    reg [3:0] next_state;

    // State encoding
    localparam S0 = 4'b0000; // Initial state
    localparam S1 = 4'b0001; // Detected 0b001
    localparam S2 = 4'b0010; // Detected 0b101
    localparam S3 = 4'b0011; // Detected 0b110
    localparam S4 = 4'b0100; // Detected 0b000
    localparam S5 = 4'b0101; // Detected 0b110
    localparam S6 = 4'b0110; // Detected 0b011
    localparam S7 = 4'b0111; // Detected 0b101

    // Synchronous reset and state transition
    always @(posedge clk or negedge n_rst) begin
        if (!n_rst) begin
            state <= S0;
            seq_found <= 0;
        end else begin
            state <= next_state;
            seq_found <= (next_state == S7); // Indicate sequence found when reaching state S7
        end
    end

    // Next state logic
    always @(*) begin
        case (state)
            S0: next_state = (data == 3'b001) ? S1 : S0;
            S1: next_state = (data == 3'b101) ? S2 : S0;
            S2: next_state = (data == 3'b110) ? S3 : S0;
            S3: next_state = (data == 3'b000) ? S4 : S0;
            S4: next_state = (data == 3'b110) ? S5 : S0;
            S5: next_state = (data == 3'b110) ? S5 : S6;
            S6: next_state = (data == 3'b011) ? S7 : S0;
            S7: next_state = (data == 3'b101) ? S2 : S0;
            default: next_state = S0;
        endcase
    end
endmodule
