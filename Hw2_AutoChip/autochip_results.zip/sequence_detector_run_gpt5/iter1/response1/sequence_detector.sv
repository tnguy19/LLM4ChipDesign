module sequence_detector (
    input  wire        Clock,
    input  wire        Reset_n,   // Active-low reset
    input  wire [2:0]  Data,
    output reg         Sequence_found
);

    // Shift register holds the last 8 symbols (8 * 3 bits = 24 bits)
    reg [23:0] shift_reg;

    // Target pattern: 0b001, 0b101, 0b110, 0b000, 0b110, 0b110, 0b011, 0b101
    localparam [23:0] PATTERN = 24'b001_101_110_000_110_110_011_101;

    // Asynchronous active-low reset, detect on the same cycle the last symbol arrives
    always @(posedge Clock or negedge Reset_n) begin
        if (!Reset_n) begin
            shift_reg       <= 24'd0;
            Sequence_found  <= 1'b0;
        end else begin
            // Shift in the current Data sample
            shift_reg      <= {shift_reg[20:0], Data};
            // Assert a 1-cycle pulse when the last 8 samples match the pattern
            Sequence_found <= ({shift_reg[20:0], Data} == PATTERN);
        end
    end

endmodule
