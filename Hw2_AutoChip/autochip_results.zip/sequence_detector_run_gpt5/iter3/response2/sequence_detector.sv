module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,        // Active-low reset
    input  wire [2:0]  data,           // 3-bit symbol input
    output reg         sequence_found  // 1-cycle pulse when sequence detected
);

    // Pattern symbols
    localparam [2:0] P0 = 3'b001;
    localparam [2:0] P1 = 3'b101;
    localparam [2:0] P2 = 3'b110;
    localparam [2:0] P3 = 3'b000;
    localparam [2:0] P4 = 3'b110;
    localparam [2:0] P5 = 3'b110;
    localparam [2:0] P6 = 3'b011;
    localparam [2:0] P7 = 3'b101;

    // State encodes how many leading symbols have been matched so far (0..7)
    reg [3:0] state, next_state;
    reg       next_sequence_found;

    // Next-state and output logic
    always @* begin
        next_state          = state;
        next_sequence_found = 1'b0;

        case (state)
            4'd0: begin
                if (data == P0) next_state = 4'd1;
                else            next_state = 4'd0;
            end

            4'd1: begin
                if (data == P1)       next_state = 4'd2;
                else if (data == P0)  next_state = 4'd1; // allow immediate restart
                else                  next_state = 4'd0;
            end

            4'd2: begin
                if (data == P2)       next_state = 4'd3;
                else if (data == P0)  next_state = 4'd1;
                else                  next_state = 4'd0;
            end

            4'd3: begin
                if (data == P3)       next_state = 4'd4;
                else if (data == P0)  next_state = 4'd1;
                else                  next_state = 4'd0;
            end

            4'd4: begin
                if (data == P4)       next_state = 4'd5;
                else if (data == P0)  next_state = 4'd1;
                else                  next_state = 4'd0;
            end

            4'd5: begin
                if (data == P5)       next_state = 4'd6;
                else if (data == P0)  next_state = 4'd1;
                else                  next_state = 4'd0;
            end

            4'd6: begin
                if (data == P6)       next_state = 4'd7;
                else if (data == P0)  next_state = 4'd1;
                else                  next_state = 4'd0;
            end

            4'd7: begin
                if (data == P7) begin
                    // Full sequence matched on this cycle
                    next_sequence_found = 1'b1;
                    // For this specific pattern, no proper suffix equals the prefix,
                    // so we reset to look for a new sequence on the next symbol.
                    next_state = 4'd0;
                end else if (data == P0) begin
                    next_state = 4'd1;
                end else begin
                    next_state = 4'd0;
                end
            end

            default: begin
                next_state = 4'd0;
            end
        endcase
    end

    // Sequential logic with asynchronous active-low reset
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state           <= 4'd0;
            sequence_found  <= 1'b0;
        end else begin
            state           <= next_state;
            sequence_found  <= next_sequence_found;
        end
    end

endmodule
