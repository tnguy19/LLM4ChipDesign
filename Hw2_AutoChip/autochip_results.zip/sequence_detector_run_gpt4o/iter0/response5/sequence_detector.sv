module sequence_detector (
    input wire clk,
    input wire rst_n,  // Active-low reset
    input wire [2:0] data,
    output reg seq_found
);

    // States for the state machine
    typedef enum logic [3:0] {
        S0,  // Initial state
        S1,  // Detected 001
        S2,  // Detected 101
        S3,  // Detected 110
        S4,  // Detected 000
        S5,  // Detected 110 (second occurrence)
        S6,  // Detected 110 (third occurrence)
        S7,  // Detected 011
        S8   // Detected 101 (second occurrence, sequence complete)
    } state_t;

    state_t current_state, next_state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            current_state <= S0;
        else
            current_state <= next_state;
    end

    always @(*) begin
        next_state = current_state;  // Default value
        seq_found = 1'b0;            // Default output

        case (current_state)
            S0: if (data == 3'b001) next_state = S1;

            S1: if (data == 3'b101) next_state = S2;
                else next_state = S0;

            S2: if (data == 3'b110) next_state = S3;
                else next_state = S0;

            S3: if (data == 3'b000) next_state = S4;
                else next_state = S0;

            S4: if (data == 3'b110) next_state = S5;
                else next_state = S0;

            S5: if (data == 3'b110) next_state = S6;
                else next_state = S0;

            S6: if (data == 3'b011) next_state = S7;
                else next_state = S0;

            S7: if (data == 3'b101) begin
                    next_state = S8;
                    seq_found = 1'b1;
                end else next_state = S0;

            S8: begin
                seq_found = 1'b1;  // Stay in this state, asserting seq_found
                if (data == 3'b001) next_state = S1;  // Optionally restart detection
                else next_state = S0;
            end

            default: next_state = S0;
        endcase
    end

endmodule
