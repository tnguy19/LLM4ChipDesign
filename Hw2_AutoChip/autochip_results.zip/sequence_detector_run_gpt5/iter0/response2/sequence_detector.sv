module sequence_detector (
    input  wire        clk,        // Clock
    input  wire        rst_n,      // Active-low reset
    input  wire [2:0]  data,       // 3-bit input data
    output reg         sequence_found // 1 when sequence detected (1-cycle pulse)
);

    // Pattern to detect (chronological order: oldest -> newest)
    // 0b001, 0b101, 0b110, 0b000, 0b110, 0b110, 0b011, 0b101
    localparam [23:0] PATTERN = {
        3'b001,
        3'b101,
        3'b110,
        3'b000,
        3'b110,
        3'b110,
        3'b011,
        3'b101
    };

    reg [23:0] window;        // Shift register holding the last 8 samples (MSB = oldest, LSB = newest)
    reg [3:0]  sample_count;  // Counts up to 8 to qualify window as valid

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            window          <= 24'd0;
            sample_count    <= 4'd0;
            sequence_found  <= 1'b0;
        end else begin
            // Shift in the newest 3-bit sample
            window <= {window[20:0], data};

            // Track how many valid samples we have (saturate at 8)
            if (sample_count < 8)
                sample_count <= sample_count + 1'b1;
            else
                sample_count <= sample_count;

            // Assert sequence_found for one cycle when the last 8 samples match
            // Use the "next" window content in the comparison
            if ((sample_count >= 4'd7) && ({window[20:0], data} == PATTERN))
                sequence_found <= 1'b1;
            else
                sequence_found <= 1'b0;
        end
    end

endmodule
