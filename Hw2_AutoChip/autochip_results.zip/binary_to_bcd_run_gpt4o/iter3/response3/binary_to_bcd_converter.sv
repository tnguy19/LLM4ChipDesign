module binary_to_bcd_converter(
    input [4:0] binary_input,
    output reg [7:0] bcd_output
);
    integer i;
    
    always @ (binary_input) begin
        // Initialize BCD output
        bcd_output = 8'b00000000;

        // Process binary input to BCD format
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift left by 1
            bcd_output = {bcd_output[6:0], binary_input[i]};
            
            // Add 3 to BCD digits if they are 5 or more
            if (bcd_output[3:0] >= 5)
                bcd_output[3:0] = bcd_output[3:0] + 3;
            if (bcd_output[7:4] >= 5)
                bcd_output[7:4] = bcd_output[7:4] + 3;
        end
    end
endmodule
