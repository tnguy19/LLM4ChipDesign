module binary_to_bcd_converter (
    input [4:0] binary_input,
    output reg [7:0] bcd
);
    integer i;
    reg [3:0] tens, ones;

    always @(*) begin
        bcd = 8'b0; // Clear BCD output
        tens = 4'b0; // Clear tens place
        ones = 4'b0; // Clear ones place
        
        // Convert binary to BCD using shift-and-add technique
        for (i = 0; i < 5; i = i + 1) begin
            // Shift left by 1
            bcd = {tens, ones}; // Concatenate tens and ones for shifting
            tens = bcd[7:4];
            ones = bcd[3:0];

            // Add one if tens or ones >= 5
            if (ones >= 5) ones = ones + 4'b0011; // Add 3 to ones place if >= 5
            if (tens >= 5) tens = tens + 4'b0011; // Add 3 to tens place if >= 5
        end
        
        // Assign final BCD output
        bcd = {tens, ones};
    end
endmodule
