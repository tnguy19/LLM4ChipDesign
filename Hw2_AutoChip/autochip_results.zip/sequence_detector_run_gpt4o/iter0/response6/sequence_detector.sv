module sequence_detector (
    input wire clk,
    input wire n_reset,  // Active-low reset
    input wire [2:0] data,
    output reg sequence_found
);

    // State encoding
    typedef enum reg [2:0] {
        S0 = 3'd0,
        S1 = 3'd1,
        S2 = 3'd2,
        S3 = 3'd3,
        S4 = 3'd4,
        S5 = 3'd5,
        S6 = 3'd6,
        S7 = 3'd7
    } state_t;

    reg [2:0] current_state, next_state;

    // Combinational logic for state transitions
    always @(*) begin
        next_state = current_state;
        sequence_found = 1'b0;  // Default output

        case (current_state)
            S0: begin
                if (data == 3'b001) next_state = S1;
            end
            S1: begin
                if (data == 3'b101) next_state = S2;
                else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            S2: begin
                if (data == 3'b110) next_state = S3;
                else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            S3: begin
                if (data == 3'b000) next_state = S4;
                else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            S4: begin
                if (data == 3'b110) next_state = S5;
                else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            S5: begin
                if (data == 3'b110) next_state = S6;
                else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            S6: begin
                if (data == 3'b011) next_state = S7;
                else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            S7: begin
                if (data == 3'b101) begin
                    next_state = S0;
                    sequence_found = 1'b1;  // Sequence detected
                end else if (data == 3'b001) next_state = S1;
                else next_state = S0;
            end
            default: next_state = S0;
        endcase
    end

    // Sequential logic for state flip-flops
    always @(posedge clk or negedge n_reset) begin
        if (!n_reset) begin
            current_state <= S0;
        end else begin
            current_state <= next_state;
        end
    end

endmodule
