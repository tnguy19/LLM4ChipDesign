module mux4_1(input [1:0] sel, input [3:0] in, output reg out);
always @* begin
    if (!sel[1]) begin
        out = sel[0] ? in[1] : in[0];
    end else begin
        out = sel[0] ? in[3] : in[2];
    end
end
endmodule
