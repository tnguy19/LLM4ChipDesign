module sequence_detector (
    input wire clk,
    input wire rst_n,  // Active-low reset
    input wire [2:0] data_in,
    output reg sequence_found
);

    // State encoding
    typedef enum logic [3:0] {
        S0,  // Initial state
        S1,  // After recognizing 0b001
        S2,  // After recognizing 0b101
        S3,  // After recognizing 0b110
        S4,  // After recognizing 0b000
        S5,  // After recognizing 0b110
        S6,  // After recognizing 0b110
        S7   // After recognizing 0b011
    } state_t;

    state_t current_state, next_state;

    // State transition logic
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= S0;
        end else begin
            current_state <= next_state;
        end
    end

    // Next state logic based on input data sequence
    always @(*) begin
        next_state = current_state;
        sequence_found = 1'b0;
        
        case (current_state)
            S0: begin
                if (data_in == 3'b001)
                    next_state = S1;
            end
            
            S1: begin
                if (data_in == 3'b101)
                    next_state = S2;
                else if (data_in == 3'b001)
                    next_state = S1;  // Stay on S1 if fails
                else
                    next_state = S0;  // Reset if wrong sequence
            end

            S2: begin
                if (data_in == 3'b110)
                    next_state = S3;
                else if (data_in == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end

            S3: begin
                if (data_in == 3'b000)
                    next_state = S4;
                else if (data_in == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end

            S4: begin
                if (data_in == 3'b110)
                    next_state = S5;
                else if (data_in == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end

            S5: begin
                if (data_in == 3'b110)
                    next_state = S6;
                else if (data_in == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end

            S6: begin
                if (data_in == 3'b011)
                    next_state = S7;
                else if (data_in == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end

            S7: begin
                if (data_in == 3'b101) begin
                    next_state = S0;
                    sequence_found = 1'b1;  // Sequence is recognized
                end else if (data_in == 3'b001) begin
                    next_state = S1;
                end else begin
                    next_state = S0;
                end
            end

            default: next_state = S0;
        endcase
    end

endmodule
