module sequence_detector(
    input wire clk,           // Changed Clock to clk to match the testbench
    input wire reset_n,       // Active-low reset
    input wire [2:0] data,    // Changed Data to data to match the testbench
    output reg sequence_found // Changed SequenceFound to sequence_found to match the testbench
);

    // State definitions as parameters
    parameter S0 = 4'd0;
    parameter S1 = 4'd1;
    parameter S2 = 4'd2;
    parameter S3 = 4'd3;
    parameter S4 = 4'd4;
    parameter S5 = 4'd5;
    parameter S6 = 4'd6;
    parameter S7 = 4'd7;
    parameter S8 = 4'd8;

    // State register
    reg [3:0] current_state, next_state;

    // State transition logic
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n)
            current_state <= S0;
        else
            current_state <= next_state;
    end

    // Next state logic
    always @(*) begin
        case (current_state)
            S0: next_state = (data == 3'b001) ? S1 : S0;
            S1: next_state = (data == 3'b101) ? S2 : S0;
            S2: next_state = (data == 3'b110) ? S3 : S0;
            S3: next_state = (data == 3'b000) ? S4 : S0;
            S4: next_state = (data == 3'b110) ? S5 : S0;
            S5: next_state = (data == 3'b110) ? S6 : S0;
            S6: next_state = (data == 3'b011) ? S7 : S0;
            S7: next_state = (data == 3'b101) ? S8 : S0;
            S8: next_state = S0;
            default: next_state = S0;
        endcase
    end

    // Output logic
    always @(current_state) begin
        sequence_found = (current_state == S8);
    end

endmodule
