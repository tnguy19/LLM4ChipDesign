module binary_to_bcd_converter(
    input [4:0] binary_input,
    output reg [7:0] bcd_output
);
    integer i;
    reg [7:0] bcd;
    
    always @(binary_input) begin
        // Initialize BCD output to zero
        bcd = 8'b0;
        
        // Shift and add 3 algorithm
        for (i = 0; i < 5; i = i + 1) begin
            // Check each nibble if they are >= 5
            if (bcd[7:4] >= 5)
                bcd[7:4] = bcd[7:4] + 3; // Add 3 to tens place if needed
            if (bcd[3:0] >= 5)
                bcd[3:0] = bcd[3:0] + 3; // Add 3 to ones place if needed
            
            // Shift the entire register to the left
            bcd = {bcd[6:0], binary_input[4-i]};
        end
        
        // Assign bcd to output
        bcd_output = bcd;
    end
endmodule
