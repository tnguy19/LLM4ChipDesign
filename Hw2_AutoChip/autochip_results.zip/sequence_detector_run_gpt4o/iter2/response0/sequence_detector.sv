module sequence_detector(
    input wire Clock,
    input wire reset_n,  // Active-low reset
    input wire [2:0] Data,
    output reg SequenceFound
);

    // State definitions
    typedef enum logic [3:0] {
        S0,  // Initial state
        S1,  // Detecting 0b001
        S2,  // Detecting 0b101
        S3,  // Detecting 0b110
        S4,  // Detecting 0b000
        S5,  // Detecting 0b110 again
        S6,  // Detecting another 0b110
        S7,  // Detecting 0b011
        S8   // Detecting 0b101
    } state_t;

    state_t current_state, next_state;

    // State transition logic
    always @(posedge Clock or negedge reset_n) begin
        if (!reset_n)
            current_state <= S0;
        else
            current_state <= next_state;
    end

    // Next state logic
    always @(*) begin
        case (current_state)
            S0: next_state = (Data == 3'b001) ? S1 : S0;
            S1: next_state = (Data == 3'b101) ? S2 : S0;
            S2: next_state = (Data == 3'b110) ? S3 : S0;
            S3: next_state = (Data == 3'b000) ? S4 : S0;
            S4: next_state = (Data == 3'b110) ? S5 : S0;
            S5: next_state = (Data == 3'b110) ? S6 : S0;
            S6: next_state = (Data == 3'b011) ? S7 : S0;
            S7: next_state = (Data == 3'b101) ? S8 : S0;
            S8: next_state = S0;
            default: next_state = S0;
        endcase
    end

    // Output logic
    always @(*) begin
        SequenceFound = (current_state == S8);
    end

endmodule
