module mux64_1(input [5:0] sel, input [63:0] in, output reg out);
  always @* begin
    out = in[sel];
  end
endmodule
