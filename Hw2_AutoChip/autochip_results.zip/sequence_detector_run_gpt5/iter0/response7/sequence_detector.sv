module sequence_detector (
    input  wire        clk,     // Clock
    input  wire        rst_n,   // Active-low reset
    input  wire [2:0]  data,    // 3-bit input data
    output reg         seq_found // Pulses high for 1 cycle when sequence is found
);

    // Target sequence (8 symbols of 3 bits each):
    // 001, 101, 110, 000, 110, 110, 011, 101
    localparam [23:0] PATTERN = {3'b001, 3'b101, 3'b110, 3'b000, 3'b110, 3'b110, 3'b011, 3'b101};

    // Shift register window holding the last 8 input symbols (24 bits total).
    // MSBs hold the oldest symbol, LSBs hold the most recent.
    reg [23:0] window;

    // Compute next window and whether it matches after incorporating current input.
    wire [23:0] next_window = {window[20:0], data};
    wire        match_next  = (next_window == PATTERN);

    // Asynchronous active-low reset, sample on rising clock edge.
    // seq_found pulses high for one cycle when the new window matches the pattern.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            window    <= 24'd0;
            seq_found <= 1'b0;
        end else begin
            window    <= next_window;
            seq_found <= match_next;
        end
    end

endmodule
