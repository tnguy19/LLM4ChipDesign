module binary_to_bcd_converter(
    input [4:0] binary_input,
    output reg [7:0] bcd_output
);
    reg [7:0] bcd;
    integer i;

    always @ (binary_input) begin
        // Initialize bcd to zero
        bcd = 8'b00000000;

        // Iterate through each bit in the binary input
        for (i = 4; i >= 0; i = i - 1) begin
            // Add 3 to columns if necessary
            if (bcd[3:0] >= 5)
                bcd[3:0] = bcd[3:0] + 3;
            if (bcd[7:4] >= 5)
                bcd[7:4] = bcd[7:4] + 3;
            
            // Shift left the entire BCD by 1 to make space for the next bit of the binary input
            bcd = {bcd[6:0], binary_input[i]};
        end
        
        bcd_output = bcd;  // Assign the processed BCD output
    end
endmodule
