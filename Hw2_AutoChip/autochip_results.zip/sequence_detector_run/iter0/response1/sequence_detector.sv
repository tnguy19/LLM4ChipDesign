module sequence_detector (
    input wire clk,
    input wire reset_n,
    input wire [2:0] data,
    output reg seq_found
);

    typedef enum reg [3:0] {
        IDLE,
        S0_001,
        S1_101,
        S2_110,
        S3_000,
        S4_110_1,
        S5_110_2,
        S6_011,
        S7_101_2
    } state_t;

    state_t current_state, next_state;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            current_state <= IDLE;
            seq_found <= 0;
        end else begin
            current_state <= next_state;
        end
    end

    always @(*) begin
        seq_found = 0;
        case (current_state)
            IDLE: begin
                if (data == 3'b001) next_state = S0_001;
                else next_state = IDLE;
            end
            S0_001: begin
                if (data == 3'b101) next_state = S1_101;
                else next_state = IDLE;
            end
            S1_101: begin
                if (data == 3'b110) next_state = S2_110;
                else next_state = IDLE;
            end
            S2_110: begin
                if (data == 3'b000) next_state = S3_000;
                else next_state = IDLE;
            end
            S3_000: begin
                if (data == 3'b110) next_state = S4_110_1;
                else next_state = IDLE;
            end
            S4_110_1: begin
                if (data == 3'b110) next_state = S5_110_2;
                else next_state = IDLE;
            end
            S5_110_2: begin
                if (data == 3'b011) next_state = S6_011;
                else next_state = IDLE;
            end
            S6_011: begin
                if (data == 3'b101) next_state = S7_101_2;
                else next_state = IDLE;
            end
            S7_101_2: begin
                seq_found = 1;
                next_state = IDLE; // Return to IDLE after finding the sequence
            end
            default: next_state = IDLE;
        endcase
    end
endmodule
