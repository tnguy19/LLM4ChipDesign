module shift_register (
    input wire clk,
    input wire reset_n,
    input wire data_in,
    input wire shift_en,
    output reg [7:0] data_out
);

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            data_out <= 8'b0; // Reset the shift register to 0
        end else if (shift_en) begin
            data_out <= {data_out[6:0], data_in}; // Shift left and add new data bit
        end
    end

endmodule
