module shift_register (
    input wire clk,
    input wire rst_n,
    input wire data_in,
    input wire shift_en,
    output reg [7:0] data_out
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= 8'b0;
        end else if (shift_en) begin
            data_out <= {data_out[6:0], data_in};
        end
    end

endmodule
