module binary_to_bcd_converter(
    input [4:0] binary_in,
    output reg [7:0] bcd_out
);

    integer i;
    reg [7:0] bcd;

    always @(*) begin
        // Initialize BCD to zero
        bcd = 8'b0000_0000;

        // Shift and add 3 algorithm
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift left the entire BCD number
            bcd = {bcd[6:0], binary_in[i]};
            
            // If 4-bit region is greater than 4, add 3
            if (bcd[3:0] > 4)
                bcd[3:0] = bcd[3:0] + 3;

            if (bcd[7:4] > 4)
                bcd[7:4] = bcd[7:4] + 3;
        end

        // Output the BCD
        bcd_out = bcd;
    end
endmodule
