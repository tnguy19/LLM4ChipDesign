module seq_detector_3b (
    input  wire       clk,
    input  wire       rst_n,    // Active-low asynchronous reset
    input  wire [2:0] data,     // 3-bit input symbol
    output reg        seq_found // Pulses high for 1 clk when sequence is detected
);

    // Sequence to detect (8 symbols of 3 bits each):
    // 001, 101, 110, 000, 110, 110, 011, 101
    localparam [2:0]
        P0 = 3'b001,
        P1 = 3'b101,
        P2 = 3'b110,
        P3 = 3'b000,
        P4 = 3'b110,
        P5 = 3'b110,
        P6 = 3'b011,
        P7 = 3'b101;

    // State encodes how many symbols matched so far (0..7)
    localparam [3:0]
        ST0 = 4'd0, // 0 matched
        ST1 = 4'd1, // matched P0
        ST2 = 4'd2, // matched P0..P1
        ST3 = 4'd3, // matched P0..P2
        ST4 = 4'd4, // matched P0..P3
        ST5 = 4'd5, // matched P0..P4
        ST6 = 4'd6, // matched P0..P5
        ST7 = 4'd7; // matched P0..P6 (expecting P7 next)

    reg [3:0] state, next_state;

    // Next-state logic with simple overlap handling
    always @* begin
        next_state = state;
        case (state)
            ST0: begin
                if (data == P0) next_state = ST1;
                else            next_state = ST0;
            end
            ST1: begin
                if      (data == P1) next_state = ST2;
                else if (data == P0) next_state = ST1; // restart with new P0
                else                 next_state = ST0;
            end
            ST2: begin
                if      (data == P2) next_state = ST3;
                else if (data == P0) next_state = ST1;
                else                 next_state = ST0;
            end
            ST3: begin
                if      (data == P3) next_state = ST4;
                else if (data == P0) next_state = ST1;
                else                 next_state = ST0;
            end
            ST4: begin
                if      (data == P4) next_state = ST5;
                else if (data == P0) next_state = ST1;
                else                 next_state = ST0;
            end
            ST5: begin
                if      (data == P5) next_state = ST6;
                else if (data == P0) next_state = ST1;
                else                 next_state = ST0;
            end
            ST6: begin
                if      (data == P6) next_state = ST7;
                else if (data == P0) next_state = ST1;
                else                 next_state = ST0;
            end
            ST7: begin
                if (data == P7) begin
                    // Full sequence matched on this symbol; fall-through for overlap
                    if (P7 == P0) next_state = ST1;
                    else          next_state = ST0;
                end else if (data == P0) begin
                    next_state = ST1;
                end else begin
                    next_state = ST0;
                end
            end
            default: next_state = ST0;
        endcase
    end

    // State and output registers
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= ST0;
            seq_found <= 1'b0;
        end else begin
            state     <= next_state;
            // Pulse when final symbol of sequence is seen while in ST7
            seq_found <= (state == ST7) && (data == P7);
        end
    end

endmodule
