module sequence_detector (
    input  wire        clk,
    input  wire        rst_n,     // Active-low asynchronous reset
    input  wire [2:0]  data,      // 3-bit input symbol each clock
    output reg         seq_found  // Pulses high for 1 clk when sequence is detected
);

    // Target sequence (oldest to newest symbol):
    // 001, 101, 110, 000, 110, 110, 011, 101
    localparam [23:0] PATTERN = 24'b001_101_110_000_110_110_011_101;

    // Shift register window holding the last 8 symbols (8*3 = 24 bits)
    // Bits [23:21] = oldest symbol, [2:0] = newest symbol
    reg  [23:0] window;

    // Counter to ensure we have seen at least 8 symbols before detecting
    reg  [3:0]  count;

    // Next-state computations
    wire [23:0] window_next = {window[20:0], data};                // Shift in newest 3-bit symbol
    wire [3:0]  count_next  = (count < 4'd8) ? (count + 4'd1) : 4'd8;
    wire        detect_next = (count_next == 4'd8) && (window_next == PATTERN);

    // Sequential logic with active-low asynchronous reset
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            window    <= 24'd0;
            count     <= 4'd0;
            seq_found <= 1'b0;
        end else begin
            window    <= window_next;
            count     <= count_next;
            seq_found <= detect_next; // 1-cycle pulse when the sequence just arrived
        end
    end

endmodule
