module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,   // Active-low reset
    input  wire [2:0]  data,
    output reg         sequence_found
);

    // Sequence tokens (3-bit each) in order:
    // 0: 001
    // 1: 101
    // 2: 110
    // 3: 000
    // 4: 110
    // 5: 110
    // 6: 011
    // 7: 101
    function [2:0] seq_token;
        input [3:0] idx;
        begin
            case (idx)
                4'd0: seq_token = 3'b001;
                4'd1: seq_token = 3'b101;
                4'd2: seq_token = 3'b110;
                4'd3: seq_token = 3'b000;
                4'd4: seq_token = 3'b110;
                4'd5: seq_token = 3'b110;
                4'd6: seq_token = 3'b011;
                4'd7: seq_token = 3'b101;
                default: seq_token = 3'b000;
            endcase
        end
    endfunction

    // Index of next expected token in the sequence
    reg [3:0] idx;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            idx            <= 4'd0;
            sequence_found <= 1'b0;
        end else begin
            // Default: no match pulse
            sequence_found <= 1'b0;

            if (data == seq_token(idx)) begin
                // Current token matched expected token
                if (idx == 4'd7) begin
                    // Full sequence matched - assert 1-cycle pulse
                    sequence_found <= 1'b1;
                    // No proper overlap for this pattern; restart from 0
                    idx <= 4'd0;
                end else begin
                    // Advance to expect next token
                    idx <= idx + 4'd1;
                end
            end else begin
                // Mismatch: if current token equals first token, start from 1, else from 0
                if (data == seq_token(4'd0)) begin
                    idx <= 4'd1;
                end else begin
                    idx <= 4'd0;
                end
            end
        end
    end

endmodule
