module binary_to_bcd_converter (
    input [4:0] binary_input,
    output reg [7:0] bcd_output
);

    integer i;

    always @(*) begin
        // Initialize BCD output
        bcd_output = 8'b0;

        // Convert binary to BCD using shifting method
        for (i = 0; i < 5; i = i + 1) begin
            // Shift BCD output left by 1
            bcd_output = {bcd_output[6:0], 1'b0};

            // If lower half (1's place) exceeds 9, adjust
            if (bcd_output[3:0] > 4'd9) begin
                bcd_output[3:0] = bcd_output[3:0] + 4'd6;
            end
            
            // If upper half (10's place) exceeds 9, adjust
            if (bcd_output[7:4] > 4'd9) begin
                bcd_output[7:4] = bcd_output[7:4] + 4'd6;
            end

            // Add the next bit of the binary input
            bcd_output[3:0] = bcd_output[3:0] + (binary_input[4-i] ? 1'b1 : 1'b0);
        end
    end

endmodule
