module shift_register (
    input wire clk,
    input wire nreset,
    input wire data_in,
    input wire shift_enable,
    output reg [7:0] data_out
);

    always @(posedge clk or negedge nreset) begin
        if (!nreset) begin
            data_out <= 8'b0; // Reset output to 0
        end else if (shift_enable) begin
            data_out <= {data_out[6:0], data_in}; // Shift left and input new data
        end
    end

endmodule
