module binary_to_bcd_converter (
    input [4:0] binary_in,
    output reg [7:0] bcd_out
);
    integer i;
    reg [3:0] tens;
    reg [3:0] ones;

    always @(binary_in) begin
        tens = 4'd0;
        ones = 4'd0;

        // Convert binary to BCD
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift left (multiply by 2)
            tens = {tens[2:0], ones[3]};
            ones = {ones[2:0], binary_in[i]};
            
            // Add 3 if a BCD digit is >= 5
            if (ones >= 5)
                ones = ones + 4'd3;
            if (tens >= 5)
                tens = tens + 4'd3;
        end

        bcd_out = {tens, ones};
    end
endmodule
