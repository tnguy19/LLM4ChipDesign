module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,       // Active-low reset
    input  wire [2:0]  data,          // 3-bit input symbol
    output reg         sequence_found // 1-cycle pulse when sequence is detected
);

    // Function that returns the expected symbol at position i (0..7)
    function automatic [2:0] pat_symbol;
        input [3:0] i;
        begin
            case (i)
                4'd0: pat_symbol = 3'b001;
                4'd1: pat_symbol = 3'b101;
                4'd2: pat_symbol = 3'b110;
                4'd3: pat_symbol = 3'b000;
                4'd4: pat_symbol = 3'b110;
                4'd5: pat_symbol = 3'b110;
                4'd6: pat_symbol = 3'b011;
                4'd7: pat_symbol = 3'b101;
                default: pat_symbol = 3'b000;
            endcase
        end
    endfunction

    // Index of how many consecutive symbols have been matched so far (0..8)
    reg [3:0] idx;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            idx            <= 4'd0;
            sequence_found <= 1'b0;
        end else begin
            // Default: deassert output; assert only on the exact match cycle
            sequence_found <= 1'b0;

            if (data == pat_symbol(idx)) begin
                // Current symbol matches the expected one at this position
                if (idx == 4'd7) begin
                    // Full sequence matched on this cycle
                    sequence_found <= 1'b1;
                    // After a full match, restart matching from the beginning
                    // (simple restart; can be extended for overlap handling if needed)
                    idx <= 4'd0;
                end else begin
                    // Advance to expect the next symbol
                    idx <= idx + 4'd1;
                end
            end else begin
                // Mismatch: if this symbol equals the first pattern symbol,
                // immediately start from index 1, else reset to 0.
                if (data == pat_symbol(4'd0)) begin
                    idx <= 4'd1;
                end else begin
                    idx <= 4'd0;
                end
            end
        end
    end

endmodule
