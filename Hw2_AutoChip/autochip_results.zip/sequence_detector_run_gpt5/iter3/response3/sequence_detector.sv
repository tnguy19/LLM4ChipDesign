module sequence_detector (
    input  wire       clk,
    input  wire       reset_n,      // Active-low reset
    input  wire [2:0] data,         // 3-bit input data
    output reg        sequence_found
);

    // Symbols in the target sequence:
    // 0: 0b001
    // 1: 0b101
    // 2: 0b110
    // 3: 0b000
    // 4: 0b110
    // 5: 0b110
    // 6: 0b011
    // 7: 0b101
    localparam [2:0] SYM0 = 3'b001;
    localparam [2:0] SYM1 = 3'b101;
    localparam [2:0] SYM2 = 3'b110;
    localparam [2:0] SYM3 = 3'b000;
    localparam [2:0] SYM4 = 3'b110;
    localparam [2:0] SYM5 = 3'b110;
    localparam [2:0] SYM6 = 3'b011;
    localparam [2:0] SYM7 = 3'b101;

    // State encodes how many symbols from the start of the sequence
    // have been matched so far (0..7). When in state 7 and SYM7 arrives,
    // we assert sequence_found for one cycle.
    localparam [3:0] S0 = 4'd0;
    localparam [3:0] S1 = 4'd1;
    localparam [3:0] S2 = 4'd2;
    localparam [3:0] S3 = 4'd3;
    localparam [3:0] S4 = 4'd4;
    localparam [3:0] S5 = 4'd5;
    localparam [3:0] S6 = 4'd6;
    localparam [3:0] S7 = 4'd7;

    reg [3:0] state, next_state;

    // Next-state logic (simple restart-on-first-symbol fallback)
    always @* begin
        next_state = S0;
        case (state)
            S0: begin
                if (data == SYM0) next_state = S1;
                else              next_state = S0;
            end
            S1: begin
                if (data == SYM1)      next_state = S2;
                else if (data == SYM0) next_state = S1; // restart with first symbol
                else                   next_state = S0;
            end
            S2: begin
                if (data == SYM2)      next_state = S3;
                else if (data == SYM0) next_state = S1;
                else                   next_state = S0;
            end
            S3: begin
                if (data == SYM3)      next_state = S4;
                else if (data == SYM0) next_state = S1;
                else                   next_state = S0;
            end
            S4: begin
                if (data == SYM4)      next_state = S5;
                else if (data == SYM0) next_state = S1;
                else                   next_state = S0;
            end
            S5: begin
                if (data == SYM5)      next_state = S6;
                else if (data == SYM0) next_state = S1;
                else                   next_state = S0;
            end
            S6: begin
                if (data == SYM6)      next_state = S7;
                else if (data == SYM0) next_state = S1;
                else                   next_state = S0;
            end
            S7: begin
                if (data == SYM7)      next_state = S0; // sequence complete, restart
                else if (data == SYM0) next_state = S1;
                else                   next_state = S0;
            end
            default: next_state = S0;
        endcase
    end

    // State register and output logic
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state           <= S0;
            sequence_found  <= 1'b0;
        end else begin
            state <= next_state;
            // Pulse high exactly when the final symbol of the sequence arrives
            sequence_found <= (state == S7) && (data == SYM7);
        end
    end

endmodule
