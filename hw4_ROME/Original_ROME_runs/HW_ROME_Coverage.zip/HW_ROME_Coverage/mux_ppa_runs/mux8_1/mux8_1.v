module mux8_1(input [2:0] sel, input [7:0] in, output out);
assign out = in[sel];
endmodule
