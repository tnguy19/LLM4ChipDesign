module shift_register (
    input wire clk,              // Clock input
    input wire rst_n,           // Active-low reset
    input wire data_in,         // 1-bit data input
    input wire shift_en,        // Shift enable input
    output reg [7:0] data_out   // 8-bit data output
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= 8'b0;    // Reset the shift register
        end else if (shift_en) begin
            data_out <= {data_out[6:0], data_in}; // Shift data
        end
    end

endmodule
