module sequence_detector (
    input wire clk,
    input wire nreset, // Active-low reset
    input wire [2:0] data, // 3-bit data input
    output reg seq_found // Indicates if the sequence is found
);

    // State encoding
    reg [3:0] state, next_state;

    // Define states
    localparam S0 = 4'd0; // Initial state
    localparam S1 = 4'd1; // Detected 0b001
    localparam S2 = 4'd2; // Detected 0b101
    localparam S3 = 4'd3; // Detected 0b110
    localparam S4 = 4'd4; // Detected 0b000
    localparam S5 = 4'd5; // Detected 0b110 (repeat)
    localparam S6 = 4'd6; // Detected 0b011
    localparam S7 = 4'd7; // Detected 0b101 (repeat)

    // Next state logic
    always @(*) begin
        case (state)
            S0: next_state = (data == 3'b001) ? S1 : S0;
            S1: next_state = (data == 3'b101) ? S2 : S0;
            S2: next_state = (data == 3'b110) ? S3 : S0;
            S3: next_state = (data == 3'b000) ? S4 : (data == 3'b110) ? S5 : S0;
            S4: next_state = (data == 3'b110) ? S5 : S0;
            S5: next_state = (data == 3'b011) ? S6 : S0;
            S6: next_state = (data == 3'b101) ? S7 : S0;
            S7: next_state = (data == 3'b001) ? S1 : S0;
            default: next_state = S0;
        endcase
    end

    // State register
    always @(posedge clk or negedge nreset) begin
        if (!nreset)
            state <= S0;
        else
            state <= next_state;
    end

    // Output logic
    always @(posedge clk or negedge nreset) begin
        if (!nreset)
            seq_found <= 1'b0;
        else
            seq_found <= (state == S0 && next_state != S0); // Valid sequence found
    end

endmodule
