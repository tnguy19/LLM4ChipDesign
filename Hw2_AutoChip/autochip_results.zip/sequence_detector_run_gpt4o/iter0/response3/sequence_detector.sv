module sequence_detector (
    input wire clk,
    input wire nreset, // Active-low reset
    input wire [2:0] data, // 3-bit data input
    output reg sequence_found // Output for sequence detection
);
    
    // Define state identifiers
    typedef enum logic [3:0] {
        S0, S1, S2, S3, S4, S5, S6, S7, S8
    } state_t;
    
    state_t current_state, next_state;
    
    // Sequential logic for state transitioning
    always @(posedge clk or negedge nreset) begin
        if (!nreset)
            current_state <= S0; // Reset to initial state
        else
            current_state <= next_state; // Move to the next state
    end
    
    // Next state logic and output logic
    always @(*) begin
        sequence_found = 1'b0; // Default value
        case (current_state)
            S0: begin
                if (data == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end
            S1: begin
                if (data == 3'b101)
                    next_state = S2;
                else
                    next_state = S0;
            end
            S2: begin
                if (data == 3'b110)
                    next_state = S3;
                else
                    next_state = S0;
            end
            S3: begin
                if (data == 3'b000)
                    next_state = S4;
                else
                    next_state = S0;
            end
            S4: begin
                if (data == 3'b110)
                    next_state = S5;
                else
                    next_state = S0;
            end
            S5: begin
                if (data == 3'b110)
                    next_state = S6;
                else
                    next_state = S0;
            end
            S6: begin
                if (data == 3'b011)
                    next_state = S7;
                else
                    next_state = S0;
            end
            S7: begin
                if (data == 3'b101) begin
                    next_state = S8;
                    sequence_found = 1'b1; // Sequence complete and found
                end else begin
                    next_state = S0;
                end
            end
            S8: begin
                sequence_found = 1'b0;
                next_state = S0; // Resets to initial state after detection
            end
            default: next_state = S0;
        endcase
    end
    
endmodule
