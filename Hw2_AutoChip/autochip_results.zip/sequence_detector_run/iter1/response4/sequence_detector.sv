module sequence_detector(
    input wire clk,
    input wire reset_n,
    input wire [2:0] data,
    output reg seq_found
);
    // State definitions
    typedef enum logic [2:0] {
        S0 = 3'b000, S1 = 3'b001, S2 = 3'b010, S3 = 3'b011,
        S4 = 3'b100, S5 = 3'b101, S6 = 3'b110, S7 = 3'b111
    } state_t;

    state_t current_state, next_state;

    // State transition logic
    always @(*) begin
        case (current_state)
            S0: next_state = (data == 3'b001) ? S1 : S0;
            S1: next_state = (data == 3'b101) ? S2 : S0;
            S2: next_state = (data == 3'b110) ? S3 : S0;
            S3: next_state = (data == 3'b000) ? S4 : S0;
            S4: next_state = (data == 3'b110) ? S5 : S0;
            S5: next_state = (data == 3'b110) ? S6 : S0;
            S6: next_state = (data == 3'b011) ? S7 : S0;
            S7: next_state = (data == 3'b101) ? S0 : S7;
            default: next_state = S0;
        endcase
    end

    // Sequential logic
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            current_state <= S0;
            seq_found <= 1'b0;
        end else begin
            current_state <= next_state;
            seq_found <= (current_state == S7); // Sequence found when in state S7
        end
    end
endmodule
