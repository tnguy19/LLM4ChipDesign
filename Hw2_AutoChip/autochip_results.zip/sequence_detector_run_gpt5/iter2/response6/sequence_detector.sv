module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,     // Active-low reset
    input  wire [2:0]  data,
    output reg         sequence_found
);

    // Shift register holds the last 8 symbols (8 * 3 bits = 24 bits)
    reg [23:0] shift_reg;

    // Target pattern: 0b001, 0b101, 0b110, 0b000, 0b110, 0b110, 0b011, 0b101
    localparam [23:0] PATTERN = 24'b001_101_110_000_110_110_011_101;

    // Asynchronous active-low reset; flag pulses when the 8 latest samples match
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            shift_reg       <= 24'd0;
            sequence_found  <= 1'b0;
        end else begin
            // Shift in the current data sample (newest at LSB side)
            shift_reg      <= {shift_reg[20:0], data};
            // Assert a 1-cycle pulse when the last 8 samples match the pattern
            sequence_found <= ({shift_reg[20:0], data} == PATTERN);
        end
    end

endmodule
