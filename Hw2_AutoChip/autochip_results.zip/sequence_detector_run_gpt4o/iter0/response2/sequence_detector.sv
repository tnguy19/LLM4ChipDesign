module sequence_detector(
    input wire clk,
    input wire rst_n,
    input wire [2:0] data,
    output reg sequence_found
);

    // State encoding
    typedef enum reg [3:0] {
        IDLE        = 4'b0000,
        SEQ_0B001   = 4'b0001,
        SEQ_0B101   = 4'b0010,
        SEQ_0B110_1 = 4'b0011,
        SEQ_0B000   = 4'b0100,
        SEQ_0B110_2 = 4'b0101,
        SEQ_0B110_3 = 4'b0110,
        SEQ_0B011   = 4'b0111,
        SEQ_0B101_FINAL = 4'b1000
    } state_t;

    state_t current_state, next_state;

    // Sequential logic for state transition
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            current_state <= IDLE;
        else 
            current_state <= next_state;
    end

    // Combinational logic for next state and outputs
    always @* begin
        next_state = current_state; // Default: stay in current state
        sequence_found = 1'b0; // Default: sequence not found
        
        case (current_state)
            IDLE: begin
                if (data == 3'b001)
                    next_state = SEQ_0B001;
            end
            SEQ_0B001: begin
                if (data == 3'b101)
                    next_state = SEQ_0B101;
                else if (data != 3'b001)
                    next_state = IDLE;
            end
            SEQ_0B101: begin
                if (data == 3'b110)
                    next_state = SEQ_0B110_1;
                else if (data != 3'b101)
                    next_state = IDLE;
            end
            SEQ_0B110_1: begin
                if (data == 3'b000)
                    next_state = SEQ_0B000;
                else if (data != 3'b110)
                    next_state = IDLE;
            end
            SEQ_0B000: begin
                if (data == 3'b110)
                    next_state = SEQ_0B110_2;
                else if (data != 3'b000)
                    next_state = IDLE;
            end
            SEQ_0B110_2: begin
                if (data == 3'b110)
                    next_state = SEQ_0B110_3;
                else if (data != 3'b110)
                    next_state = IDLE;
            end
            SEQ_0B110_3: begin
                if (data == 3'b011)
                    next_state = SEQ_0B011;
                else if (data != 3'b110)
                    next_state = IDLE;
            end
            SEQ_0B011: begin
                if (data == 3'b101) begin
                    next_state = SEQ_0B101_FINAL;
                    sequence_found = 1'b1; // Sequence is detected
                end else if (data != 3'b011)
                    next_state = IDLE;
            end
            SEQ_0B101_FINAL: begin
                next_state = IDLE; // Reset state after sequence detection
            end
        endcase
    end

endmodule
