module binary_to_bcd_converter(
    input [4:0] binary_input,
    output reg [7:0] BCD
);

    integer i;
    reg [3:0] ones;
    reg [3:0] tens;

    always @(*) begin
        // Initialize BCD output
        BCD = 8'b0;
        ones = 4'b0;
        tens = 4'b0;

        // Conversion process
        for (i = 0; i < 5; i = i + 1) begin
            // Shift left BCD
            if (tens >= 4'd5) tens = tens + 4'd3; // Adjust tens
            if (ones >= 4'd5) ones = ones + 4'd3; // Adjust ones
            
            // Shift BCD left by one because we're about to add a new bit
            tens = {tens[2:0], ones[3]};
            ones = {ones[2:0], binary_input[4 - i]};
        end
        // Combine tens and ones into BCD output
        BCD = {tens, ones};
    end

endmodule
