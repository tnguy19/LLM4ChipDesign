module SequenceDetector (
    input wire clk,
    input wire nreset,  // Active-low reset
    input wire [2:0] data,
    output reg sequence_found
);
  
    // State encoding
    typedef enum reg [3:0] {
        IDLE = 4'b0000,
        S1   = 4'b0001,
        S2   = 4'b0010,
        S3   = 4'b0011,
        S4   = 4'b0100,
        S5   = 4'b0101,
        S6   = 4'b0110,
        S7   = 4'b0111,
        S8   = 4'b1000
    } state_t;
  
    state_t current_state, next_state;
  
    always @(posedge clk or negedge nreset) begin
        if (!nreset)
            current_state <= IDLE;  // Reset to IDLE state
        else
            current_state <= next_state;  // Update state
    end
  
    always @(*) begin
        next_state = current_state;  // Default next state is the same as current state
        sequence_found = 1'b0;  // Default output is 0
        case (current_state)
            IDLE: begin
                if (data == 3'b001) next_state = S1;
            end
            S1: begin
                if (data == 3'b101) next_state = S2;
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S2: begin
                if (data == 3'b110) next_state = S3;
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S3: begin
                if (data == 3'b000) next_state = S4;
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S4: begin
                if (data == 3'b110) next_state = S5;
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S5: begin
                if (data == 3'b110) next_state = S6;
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S6: begin
                if (data == 3'b011) next_state = S7;
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S7: begin
                if (data == 3'b101) begin
                    next_state = S8;
                    sequence_found = 1'b1;  // Sequence found
                end
                else if (data == 3'b001) next_state = S1;
                else next_state = IDLE;
            end
            S8: begin
                next_state = IDLE;  // Reset to IDLE after sequence found
                if (data == 3'b001) next_state = S1;
            end
            default: next_state = IDLE;  // Default to IDLE state
        endcase
    end
  
endmodule
