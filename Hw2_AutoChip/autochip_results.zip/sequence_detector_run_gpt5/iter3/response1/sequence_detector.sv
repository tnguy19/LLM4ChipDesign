module sequence_detector (
    input  wire       clk,
    input  wire       reset_n,      // Active-low reset
    input  wire [2:0] data,         // 3-bit input symbol
    output reg        sequence_found
);

    // Symbols to detect in order:
    // 0: 001
    // 1: 101
    // 2: 110
    // 3: 000
    // 4: 110
    // 5: 110
    // 6: 011
    // 7: 101
    localparam [2:0] SYM0 = 3'b001;
    localparam [2:0] SYM1 = 3'b101;
    localparam [2:0] SYM2 = 3'b110;
    localparam [2:0] SYM3 = 3'b000;
    localparam [2:0] SYM4 = 3'b110;
    localparam [2:0] SYM5 = 3'b110;
    localparam [2:0] SYM6 = 3'b011;
    localparam [2:0] SYM7 = 3'b101;

    // State encodes how many consecutive symbols have matched so far (0..7)
    reg [3:0] state;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state          <= 4'd0;
            sequence_found <= 1'b0;
        end else begin
            sequence_found <= 1'b0; // default: 1-cycle pulse on detection

            case (state)
                4'd0: begin
                    if (data == SYM0) state <= 4'd1;
                    else              state <= 4'd0;
                end

                4'd1: begin
                    if (data == SYM1)      state <= 4'd2;
                    else if (data == SYM0) state <= 4'd1; // allow immediate restart
                    else                   state <= 4'd0;
                end

                4'd2: begin
                    if (data == SYM2)      state <= 4'd3;
                    else if (data == SYM0) state <= 4'd1;
                    else                   state <= 4'd0;
                end

                4'd3: begin
                    if (data == SYM3)      state <= 4'd4;
                    else if (data == SYM0) state <= 4'd1;
                    else                   state <= 4'd0;
                end

                4'd4: begin
                    if (data == SYM4)      state <= 4'd5;
                    else if (data == SYM0) state <= 4'd1;
                    else                   state <= 4'd0;
                end

                4'd5: begin
                    if (data == SYM5)      state <= 4'd6;
                    else if (data == SYM0) state <= 4'd1;
                    else                   state <= 4'd0;
                end

                4'd6: begin
                    if (data == SYM6)      state <= 4'd7;
                    else if (data == SYM0) state <= 4'd1;
                    else                   state <= 4'd0;
                end

                4'd7: begin
                    if (data == SYM7) begin
                        sequence_found <= 1'b1;  // pulse when final symbol matches
                        // Determine fallback for next cycle (simple restart logic)
                        state <= 4'd0;
                    end else if (data == SYM0) begin
                        state <= 4'd1;
                    end else begin
                        state <= 4'd0;
                    end
                end

                default: begin
                    state <= 4'd0;
                end
            endcase
        end
    end

endmodule
