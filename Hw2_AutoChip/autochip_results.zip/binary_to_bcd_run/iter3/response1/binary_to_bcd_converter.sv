module binary_to_bcd_converter (
    input [4:0] binary_input,
    output reg [7:0] bcd_output
);

    integer i;

    always @(*) begin
        // Initialize BCD output
        bcd_output = 8'b0;

        // Convert binary to BCD using the shifting method
        for (i = 0; i < 5; i = i + 1) begin
            // Shift left BCD value by 1
            bcd_output = {bcd_output[6:0], 1'b0};

            // Add current binary input bit to the BCD output
            bcd_output[0] = bcd_output[0] | binary_input[4-i];

            // Adjust BCD if needed
            if (bcd_output[3:0] > 4'd9) begin
                bcd_output[3:0] = bcd_output[3:0] + 4'd6;
            end
            if (bcd_output[7:4] > 4'd9) begin
                bcd_output[7:4] = bcd_output[7:4] + 4'd6;
            end
        end
    end

endmodule
