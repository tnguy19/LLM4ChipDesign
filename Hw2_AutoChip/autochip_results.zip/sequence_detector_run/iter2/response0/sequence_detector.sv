module sequence_detector(
    input wire clk,
    input wire reset_n,
    input wire [2:0] data,
    output reg seq_found
);
    // State definitions
    typedef enum logic [2:0] {
        S0, S1, S2, S3, S4, S5, S6, S7
    } state_t;

    state_t current_state, next_state;

    // State transition logic
    always_comb begin
        next_state = current_state; // Default to stay in current state
        case (current_state)
            S0: if (data == 3'b001) next_state = S1;
            S1: if (data == 3'b101) next_state = S2;
            S2: if (data == 3'b110) next_state = S3;
            S3: if (data == 3'b000) next_state = S4;
            S4: if (data == 3'b110) next_state = S5;
            S5: if (data == 3'b110) next_state = S6;
            S6: if (data == 3'b011) next_state = S7;
            S7: if (data == 3'b101) next_state = S0;
            default: next_state = S0;
        endcase
    end

    // Sequential logic
    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            current_state <= S0;
            seq_found <= 1'b0;
        end else begin
            current_state <= next_state;
            seq_found <= (current_state == S7); // Sequence found when in state S7
        end
    end
endmodule
