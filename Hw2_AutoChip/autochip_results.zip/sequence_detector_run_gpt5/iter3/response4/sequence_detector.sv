module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,   // Active-low reset
    input  wire [2:0]  data,
    output reg         sequence_found
);

    // Pattern to detect (in order):
    // 001, 101, 110, 000, 110, 110, 011, 101
    localparam [2:0] P0 = 3'b001;
    localparam [2:0] P1 = 3'b101;
    localparam [2:0] P2 = 3'b110;
    localparam [2:0] P3 = 3'b000;
    localparam [2:0] P4 = 3'b110;
    localparam [2:0] P5 = 3'b110;
    localparam [2:0] P6 = 3'b011;
    localparam [2:0] P7 = 3'b101;

    // State encodes how many symbols have been matched so far (0..7)
    reg [3:0] state;

    // Synchronous sequence detector (Moore-like with Mealy assertion)
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state           <= 4'd0;
            sequence_found  <= 1'b0;
        end else begin
            // Default deassert; will assert for one cycle when last symbol matches
            sequence_found <= (state == 4'd7) && (data == P7);

            case (state)
                4'd0: begin
                    if (data == P0) state <= 4'd1;
                    else            state <= 4'd0;
                end
                4'd1: begin
                    if      (data == P1) state <= 4'd2;
                    else if (data == P0) state <= 4'd1; // restart with first symbol
                    else                 state <= 4'd0;
                end
                4'd2: begin
                    if      (data == P2) state <= 4'd3;
                    else if (data == P0) state <= 4'd1;
                    else                 state <= 4'd0;
                end
                4'd3: begin
                    if      (data == P3) state <= 4'd4;
                    else if (data == P0) state <= 4'd1;
                    else                 state <= 4'd0;
                end
                4'd4: begin
                    if      (data == P4) state <= 4'd5;
                    else if (data == P0) state <= 4'd1;
                    else                 state <= 4'd0;
                end
                4'd5: begin
                    if      (data == P5) state <= 4'd6;
                    else if (data == P0) state <= 4'd1;
                    else                 state <= 4'd0;
                end
                4'd6: begin
                    if      (data == P6) state <= 4'd7;
                    else if (data == P0) state <= 4'd1;
                    else                 state <= 4'd0;
                end
                4'd7: begin
                    // If final symbol matches, we simultaneously assert sequence_found (above)
                    // and reset the state (no non-trivial overlap with prefix)
                    if      (data == P7) state <= 4'd0;
                    else if (data == P0) state <= 4'd1;
                    else                 state <= 4'd0;
                end
                default: state <= 4'd0;
            endcase
        end
    end

endmodule
