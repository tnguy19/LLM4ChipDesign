module sequence_detector(
    input wire Clock,
    input wire reset_n,  // Active-low reset
    input wire [2:0] Data,
    output reg SequenceFound
);

    // State definitions
    parameter S0 = 4'b0000,  // Initial state
              S1 = 4'b0001,  // Detecting 0b001
              S2 = 4'b0010,  // Detecting 0b101
              S3 = 4'b0011,  // Detecting 0b110
              S4 = 4'b0100,  // Detecting 0b000
              S5 = 4'b0101,  // Detecting 0b110 again
              S6 = 4'b0110,  // Detecting another 0b110
              S7 = 4'b0111,  // Detecting 0b011
              S8 = 4'b1000;  // Detecting 0b101

    reg [3:0] current_state, next_state;

    // State transition logic
    always @(posedge Clock or negedge reset_n) begin
        if (!reset_n)
            current_state <= S0;
        else
            current_state <= next_state;
    end

    // Next state logic
    always @(*) begin
        case (current_state)
            S0: next_state = (Data == 3'b001) ? S1 : S0;
            S1: next_state = (Data == 3'b101) ? S2 : S0;
            S2: next_state = (Data == 3'b110) ? S3 : S0;
            S3: next_state = (Data == 3'b000) ? S4 : S0;
            S4: next_state = (Data == 3'b110) ? S5 : S0;
            S5: next_state = (Data == 3'b110) ? S6 : S0;
            S6: next_state = (Data == 3'b011) ? S7 : S0;
            S7: next_state = (Data == 3'b101) ? S8 : S0;
            S8: next_state = S0;
            default: next_state = S0;
        endcase
    end

    // Output logic
    always @(*) begin
        SequenceFound = (current_state == S8);
    end

endmodule
