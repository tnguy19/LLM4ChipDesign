module sequence_detector_3b (
    input  wire        clk,       // Clock
    input  wire        rst_n,     // Active-low reset
    input  wire [2:0]  data,      // 3-bit data input
    output reg         seq_found  // 1-cycle pulse when sequence is detected
);

    // The sequence to detect (oldest to newest):
    // 001, 101, 110, 000, 110, 110, 011, 101
    localparam [23:0] PATTERN = {3'b001, 3'b101, 3'b110, 3'b000, 3'b110, 3'b110, 3'b011, 3'b101};

    reg [23:0] shreg;        // Shift register holding the last 8 symbols (3 bits each)
    reg [3:0]  sample_cnt;   // Counts how many symbols have been sampled (0..8)

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            shreg      <= 24'd0;
            sample_cnt <= 4'd0;
            seq_found  <= 1'b0;
        end else begin
            // Shift in the newest 3-bit symbol
            shreg <= {shreg[20:0], data};

            // Increment sample count up to 8 (number of symbols in the pattern)
            if (sample_cnt < 4'd8)
                sample_cnt <= sample_cnt + 1'b1;

            // Assert seq_found for 1 cycle when the last 8 symbols match the pattern
            // Use the "next" shift value so detection aligns with the newly sampled input
            seq_found <= (sample_cnt >= 4'd7) && ({shreg[20:0], data} == PATTERN);
        end
    end

endmodule
