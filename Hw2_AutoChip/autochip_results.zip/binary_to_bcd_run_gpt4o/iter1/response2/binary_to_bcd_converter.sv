module binary_to_bcd_converter(input [4:0] binary_in, output reg [7:0] bcd_out);
    integer i;
    
    always @ (binary_in) begin
        // Initialize BCD output
        bcd_out = 8'b00000000;
        
        // Binary to BCD conversion using Double Dabble algorithm
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift the BCD output left by one bit
            bcd_out = {bcd_out[6:0], binary_in[i]};
            
            // Add 3 to the BCD's 4-bits if it's 5 or greater
            if (bcd_out[3:0] >= 5)
                bcd_out[3:0] = bcd_out[3:0] + 3;
            if (bcd_out[7:4] >= 5)
                bcd_out[7:4] = bcd_out[7:4] + 3;
        end
    end
endmodule
