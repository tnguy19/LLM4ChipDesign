module mux2_1(input wire in1, input wire in2, input wire select, output wire out);
  assign out = (in1 & ~select) | (in2 & select);
endmodule
