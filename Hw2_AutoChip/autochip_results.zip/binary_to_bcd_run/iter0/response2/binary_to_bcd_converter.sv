module binary_to_bcd_converter (
    input [4:0] binary,
    output reg [7:0] bcd
);
    integer i;

    always @(*) begin
        // Initialize BCD output
        bcd = 8'b00000000;

        // Binary to BCD conversion using shift-and-add-3 algorithm
        for (i = 0; i < 5; i = i + 1) begin
            // Shift left by 1
            bcd = {bcd[6:0], binary[4-i]}; // Insert the next binary bit
            // Add 3 to any BCD digit that is >= 5
            if (bcd[3:0] >= 5) begin
                bcd[3:0] = bcd[3:0] + 4'b0011;
            end
            if (bcd[7:4] >= 5) begin
                bcd[7:4] = bcd[7:4] + 4'b0011;
            end
        end
    end
endmodule
