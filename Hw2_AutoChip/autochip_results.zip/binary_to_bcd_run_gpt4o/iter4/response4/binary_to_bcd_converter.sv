module binary_to_bcd_converter(
    input [4:0] binary_input,
    output reg [7:0] bcd_output
);
    integer i;
    reg [7:0] bcd_temp;
    
    always @ (binary_input) begin
        // Initialize temporary BCD and actual BCD output
        bcd_temp = 8'b00000000;
        bcd_output = 8'b00000000;

        // Process binary input to BCD format
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift left by 1
            bcd_temp = {bcd_temp[6:0], binary_input[i]};
            
            // Check and add 3 to BCD digits if they are 5 or more before shifting in new bit
            if (bcd_temp[3:0] >= 5)
                bcd_temp[3:0] = bcd_temp[3:0] + 3;
            if (bcd_temp[7:4] >= 5)
                bcd_temp[7:4] = bcd_temp[7:4] + 3;

            // Shift BCD output
            bcd_output = bcd_temp;
        end
    end
endmodule
