module sequence_detector (
    input wire clk,                // Clock input
    input wire rst_n,              // Active-low reset
    input wire [2:0] data,         // 3-bit data input
    output reg seq_found           // Sequence found output
);

    // State encoding
    typedef enum reg [2:0] {
        S0 = 3'b000,
        S1 = 3'b001,
        S2 = 3'b010,
        S3 = 3'b011,
        S4 = 3'b100,
        S5 = 3'b101,
        S6 = 3'b110
    } state_t;

    state_t current_state, next_state;

    // Sequential logic for state transition
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            current_state <= S0;
        else
            current_state <= next_state;
    end

    // Combinational logic for next state and output
    always @(*) begin
        seq_found = 0;  // Default output
        case (current_state)
            S0: begin
                if (data == 3'b001)
                    next_state = S1;
                else
                    next_state = S0;
            end
            S1: begin
                if (data == 3'b101)
                    next_state = S2;
                else
                    next_state = S0;
            end
            S2: begin
                if (data == 3'b110)
                    next_state = S3;
                else
                    next_state = S0;
            end
            S3: begin
                if (data == 3'b000)
                    next_state = S4;
                else
                    next_state = S0;
            end
            S4: begin
                if (data == 3'b110)
                    next_state = S5;
                else
                    next_state = S0;
            end
            S5: begin
                if (data == 3'b110)
                    next_state = S6;
                else
                    next_state = S0;
            end
            S6: begin
                if (data == 3'b011)
                    next_state = S1;  // Go back to initial state or another sequence
                else
                    next_state = S0;  // Reset on wrong input
            end
            default: next_state = S0; // Default state
        endcase

        // Set seq_found when a valid sequence ends
        if (current_state == S6 && data == 3'b101) 
            seq_found = 1;  // Sequence completed
    end

endmodule
