module binary_to_bcd_converter (
    input [4:0] binary_input,
    output reg [7:0] bcd
);

    integer i;

    always @(*) begin
        // Initialize BCD output
        bcd = 8'b0;

        // Convert binary to BCD using shifting method
        for (i = 0; i < 5; i = i + 1) begin
            // Shift left BCD value by 1
            bcd = {bcd[6:0], binary_input[4-i]};
            
            // Adjust BCD if needed
            if (bcd[3:0] > 4'd9) begin
                bcd[3:0] = bcd[3:0] + 4'd6;
            end
            if (bcd[7:4] > 4'd9) begin
                bcd[7:4] = bcd[7:4] + 4'd6;
            end
        end
    end

endmodule
