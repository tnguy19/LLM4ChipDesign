module sequence_detector (
    input  wire        clk,
    input  wire        rst_n,      // Active-low reset
    input  wire [2:0]  data,       // 3-bit input data
    output reg         seq_found   // Pulses high for 1 cycle when sequence is found
);

    // Store the last 7 symbols (each 3 bits) = 21 bits
    reg [20:0] hist;
    // Counter to ensure we have collected at least 7 prior symbols before checking
    reg [2:0]  sample_cnt;

    // Target 8-symbol sequence (from oldest to newest)
    // 0b001, 0b101, 0b110, 0b000, 0b110, 0b110, 0b011, 0b101
    localparam [23:0] PATTERN = {3'b001, 3'b101, 3'b110, 3'b000, 3'b110, 3'b110, 3'b011, 3'b101};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hist       <= 21'd0;
            sample_cnt <= 3'd0;
            seq_found  <= 1'b0;
        end else begin
            // Default: deassert seq_found; will assert for one cycle on match
            seq_found <= 1'b0;

            // Shift in new data (left shift: oldest on the left)
            hist <= {hist[17:0], data};

            // Increment sample counter until it reaches 7 (saturating)
            if (sample_cnt != 3'd7)
                sample_cnt <= sample_cnt + 3'd1;

            // Once we have 7 prior samples, compare the 8-sample window
            if ((sample_cnt == 3'd7) && ({hist, data} == PATTERN))
                seq_found <= 1'b1;
        end
    end

endmodule
