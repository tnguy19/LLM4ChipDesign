module binary_to_bcd_converter(
    input [4:0] binary_input, // 5-bit binary input
    output reg [7:0] bcd_output // 8-bit BCD output (4 bits for tens and 4 bits for ones)
);
    integer i;
    
    always @ (binary_input) begin
        // Initialize BCD output
        bcd_output = 8'b00000000;

        // Process binary input to BCD format
        for (i = 4; i >= 0; i = i - 1) begin
            // Shift the BCD output left by one bit
            bcd_output = {bcd_output[6:0], binary_input[i]};

            // Add 3 to the 4-bit BCD groups if they are >= 5
            if (bcd_output[3:0] >= 5)
                bcd_output[3:0] = bcd_output[3:0] + 3;
            if (bcd_output[7:4] >= 5)
                bcd_output[7:4] = bcd_output[7:4] + 3;
        end
    end
endmodule
