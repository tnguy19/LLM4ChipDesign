module sequence_detector (
    input wire clk,
    input wire nreset,    // Active-low reset
    input wire [2:0] data,
    output reg seq_found
);

    // State encoding
    typedef enum reg [3:0] {
        S0,  // Initial state
        S1,  // Detected 0b001
        S2,  // Detected 0b101
        S3,  // Detected 0b110
        S4,  // Detected 0b000
        S5,  // Detected 0b110 (second occurrence)
        S6,  // Detected 0b110 (second occurrence)
        S7,  // Detected 0b011
        S8   // Detected 0b101
    } state_t;
    
    state_t current_state, next_state;
    
    // State transition logic
    always @(*) begin
        case (current_state)
            S0: next_state = (data == 3'b001) ? S1 : S0;
            S1: next_state = (data == 3'b101) ? S2 : (data == 3'b001) ? S1 : S0;
            S2: next_state = (data == 3'b110) ? S3 : (data == 3'b101) ? S2 : S0;
            S3: next_state = (data == 3'b000) ? S4 : (data == 3'b110) ? S3 : S0;
            S4: next_state = (data == 3'b110) ? S5 : (data == 3'b000) ? S4 : S0;
            S5: next_state = (data == 3'b110) ? S6 : (data == 3'b000) ? S4 : S0;
            S6: next_state = (data == 3'b011) ? S7 : (data == 3'b110) ? S6 : S0;
            S7: next_state = (data == 3'b101) ? S8 : (data == 3'b011) ? S7 : S0;
            S8: next_state = (data == 3'b001) ? S1 : (data == 3'b101) ? S2 : S0;
            default: next_state = S0;
        endcase
    end
    
    // State update logic
    always @(posedge clk or negedge nreset) begin
        if (!nreset)
            current_state <= S0;
        else
            current_state <= next_state;
    end
    
    // Output logic
    always @(*) begin
        seq_found = (current_state == S8);
    end
    
endmodule
