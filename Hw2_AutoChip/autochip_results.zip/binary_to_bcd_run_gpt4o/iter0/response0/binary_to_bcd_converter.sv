module binary_to_bcd_converter(
    input [4:0] binary_in,
    output reg [7:0] bcd_out
);
    integer i;
    reg [27:0] shift_reg;

    always @* begin
        // Initialize the shift register with the binary input
        shift_reg = 0;
        shift_reg[4:0] = binary_in;
        
        // Perform the Double Dabble algorithm
        for(i = 0; i < 5; i = i + 1) begin
            // Check if tens or units digit needs to be incremented
            if(shift_reg[7:4] >= 5)
                shift_reg[7:4] = shift_reg[7:4] + 3;
                
            if(shift_reg[11:8] >= 5)
                shift_reg[11:8] = shift_reg[11:8] + 3;
                
            // Shift left, combining binary and BCD digits
            shift_reg = shift_reg << 1;
        end
        
        // Assign the BCD output
        bcd_out = shift_reg[11:4]; // Output 8 bits covering tens and units
    end
    
endmodule
