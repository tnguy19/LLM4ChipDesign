module sequence_detector (
    input  wire        clk,
    input  wire        reset_n,   // Active-low reset
    input  wire [2:0]  data,
    output reg         sequence_found
);

    // Store last 7 symbols; the 8th (newest) is "data" on this clock
    reg [2:0] hist [0:6];

    // Compute whether, after this clock edge (with data being the newest),
    // the last 8 symbols match the required sequence:
    // 001, 101, 110, 000, 110, 110, 011, 101
    wire match_next = (hist[6] == 3'b001) &&
                      (hist[5] == 3'b101) &&
                      (hist[4] == 3'b110) &&
                      (hist[3] == 3'b000) &&
                      (hist[2] == 3'b110) &&
                      (hist[1] == 3'b110) &&
                      (hist[0] == 3'b011) &&
                      (data    == 3'b101);

    integer i;

    // Asynchronous active-low reset; update history and sequence_found on clock
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            for (i = 0; i <= 6; i = i + 1) begin
                hist[i] <= 3'b000;
            end
            sequence_found <= 1'b0;
        end else begin
            // Shift history: oldest is at hist[6], newest goes into hist[0]
            hist[6] <= hist[5];
            hist[5] <= hist[4];
            hist[4] <= hist[3];
            hist[3] <= hist[2];
            hist[2] <= hist[1];
            hist[1] <= hist[0];
            hist[0] <= data;

            // Assert a 1-cycle pulse when the last 8 samples match the sequence
            sequence_found <= match_next;
        end
    end

endmodule
